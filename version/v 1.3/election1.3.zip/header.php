<link href="https://fonts.googleapis.com/css?family=Exo+2" rel="stylesheet"><div class="row" >
    <a href="index.php"><img src="img/top.png" class="img-responsive" width="100%"></a>
    <nav class="navbar navbar-default" style="width: 100%">
        <div class="container-fluid">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
            </div>
            <div id="navbar" class="navbar-collapse collapse">
                <ul class="nav navbar-nav" style="font-family: 'Exo 2', sans-serif;color: #122b40;font-size: 14px">
                    <li class="active"><a href="index.php">Home</a></li>
                    <li class=""><a href="#dis">District List</a></li>
                    <li><a href="http://nethnews.lk" target="_blank">Neth News</a></li>
                    <li><a href="http://nethgossip.lk" target="_blank">Neth Gossip</a></li>
                </ul>
            </div><!--/.nav-collapse -->
        </div><!--/.container-fluid -->
    </nav>
</div>
