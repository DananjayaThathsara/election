<!DOCTYPE html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../favicon.ico">

    <title>Election</title>
    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link href="css/style.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="navbar.css" rel="stylesheet">
    <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
    <!--[if lt IE 9]>
    <script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
    <script src="../../assets/js/ie-emulation-modes-warning.js"></script>
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<html>
<body>
<div class="container">
    <div class="row">
        <img src="img/top.png" class="img-responsive" width="100%">
    </div>
    <div class="row">
        <div style="width: 100%;height: 80px;background: #ccc;vertical-align: middle;text-align: center">Ad Space</div>
    </div>
    <div class="row">
        <div class="col-md-8">
            <h2> Cumilatve Results</h2>

            <table class="table table-striped">
                <thead>

                </thead>
                <tbody>
                <tr>
                    <td width="30%"><div class="ele_symbol ">
                            <img src="http://www.adaderana.lk/general-election-2015/assets/images/unp-gen-elec-15.jpg" class="img-responsive" alt="UNP">
                        </div>
                        <div class="ele_symbol_text">UNP</div>
                    </td>

                    <td>
                        <div class="candi_progress">
                            <div class="progress skill-bar">
                                <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="45.66" aria-valuemin="0" aria-valuemax="100" style="background-color: blue">
                                    <span class="skill"><i class="val">45.66%</i></span>
                                </div>
                            </div>
                            <div class="tot_vote">
                                <div  class="pull-left">Total Votes : 5,098,927</div>
                            </div>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td width="30%"><div class="ele_symbol ">
                            <img src="http://www.adaderana.lk/general-election-2015/assets/images/unp-gen-elec-15.jpg" class="img-responsive" alt="UNP">
                        </div>
                        <div class="ele_symbol_text">UNP</div>
                    </td>

                    <td>
                        <div class="candi_progress">
                            <div class="progress skill-bar">
                                <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="45.66" aria-valuemin="0" aria-valuemax="100" style="background-color: blue">
                                    <span class="skill"><i class="val">45.66%</i></span>
                                </div>
                            </div>
                            <div class="tot_vote">
                                <div  class="pull-left">Total Votes : 5,098,927</div>
                            </div>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td width="30%"><div class="ele_symbol ">
                            <img src="http://www.adaderana.lk/general-election-2015/assets/images/unp-gen-elec-15.jpg" class="img-responsive" alt="UNP">
                        </div>
                        <div class="ele_symbol_text">UNP</div>
                    </td>

                    <td>
                        <div class="candi_progress">
                            <div class="progress skill-bar">
                                <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="45.66" aria-valuemin="0" aria-valuemax="100" style="background-color: blue">
                                    <span class="skill"><i class="val">45.66%</i></span>
                                </div>
                            </div>
                            <div class="tot_vote">
                                <div  class="pull-left">Total Votes : 5,098,927</div>
                            </div>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td width="30%"><div class="ele_symbol ">
                            <img src="http://www.adaderana.lk/general-election-2015/assets/images/unp-gen-elec-15.jpg" class="img-responsive" alt="UNP">
                        </div>
                        <div class="ele_symbol_text">UNP</div>
                    </td>

                    <td>
                        <div class="candi_progress">
                            <div class="progress skill-bar">
                                <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="45.66" aria-valuemin="0" aria-valuemax="100" style="background-color: blue">
                                    <span class="skill"><i class="val">45.66%</i></span>
                                </div>
                            </div>
                            <div class="tot_vote">
                                <div  class="pull-left">Total Votes : 5,098,927</div>
                            </div>
                        </div>
                    </td>
                </tr>

                </tbody>
            </table>

                <div style="width: 100%;height: 80px;background: #ccc;text-align: center;margin: 0px;padding: 0px">Ad space</div>

        <h2>Seats</h2>
            <table class="table table-striped">
                <thead>
                <tr>
                    <th style="text-align: center">Party</th>
                    <th style="text-align: center">Selected Members</th>
                    <th style="text-align: center">Calculated Members</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                    <td>
                        <div class="ele_symbol ">
                            <img src="http://www.adaderana.lk/general-election-2015/assets/images/unp-gen-elec-15.jpg" class="img-responsive" alt="UNP">
                        </div>
                        <div class="ele_symbol_text">UNP</div>
                    </td>
                    <td style="text-align: center">6</td>
                    <td style="text-align: center">2</td>
                </tr>
                <tr>
                    <td><div class="ele_symbol ">
                            <img src="http://www.adaderana.lk/general-election-2015/assets/images/unp-gen-elec-15.jpg" class="img-responsive" alt="UNP">
                        </div>
                        <div class="ele_symbol_text">UNP</div></td>
                    <td style="text-align: center">6</td>
                    <td style="text-align: center">2</td>
                </tr>
                <tr>
                    <td><div class="ele_symbol ">
                            <img src="http://www.adaderana.lk/general-election-2015/assets/images/unp-gen-elec-15.jpg" class="img-responsive" alt="UNP">
                        </div>
                        <div class="ele_symbol_text">UNP</div></td>
                    <td style="text-align: center">6</td>
                    <td style="text-align: center">2</td>
                </tr>
                <tr>
                    <td><div class="ele_symbol ">
                            <img src="http://www.adaderana.lk/general-election-2015/assets/images/unp-gen-elec-15.jpg" class="img-responsive" alt="UNP">
                        </div>
                        <div class="ele_symbol_text">UNP</div></td>
                    <td style="text-align: center">6</td>
                    <td style="text-align: center">2</td>
                </tr>
                <tr>
                    <td><div class="ele_symbol ">
                            <img src="http://www.adaderana.lk/general-election-2015/assets/images/unp-gen-elec-15.jpg" class="img-responsive" alt="UNP">
                        </div>
                        <div class="ele_symbol_text">UNP</div></td>
                    <td style="text-align: center">6</td>
                    <td style="text-align: center">2</td>
                </tr>

                </tbody>
            </table>

                <h2>Polling District</h2>

                <table class="table table-striped">
                    <thead>
                    <tr>
                        <th>District</th>
                        <th style="text-align: center">Action</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                    include_once 'Model/dbConfig.php';
                    $query="SELECT * FROM district";
                    $result=mysql_query($query);

                    while ($row=mysql_fetch_assoc($result)){

                    ?>
                    <tr>
                        <td>
                           <?php echo $row['d_name'];?>
                        </td>
                        <td style="text-align: center"><a href="distrctInner.php">View</a></td>
                    </tr>
               <?php }?>

                    </tbody>
                </table>

       </div>

        <div class="col-md-4" id="side">
            <h2> Latest Released Results</h2>
            <br>

            <table class="table table-striped">
                <thead>
                <h4>Colombo - Borella</h4>
                </thead>
                <tbody>

                <tr>

                    <td width="30%">
                        <div class="ele_symbol ">
                            <img src="http://www.adaderana.lk/general-election-2015/assets/images/unp-gen-elec-15.jpg" class="img-responsive" alt="UNP">
                        </div>
                        <div class="ele_symbol_text">UNP</div>
                    </td>

                    <td>
                        <div class="candi_progress">
                            <div class="progress skill-bar">
                                <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="45.66" aria-valuemin="0" aria-valuemax="100" style="background-color: blue">
                                    <span class="skill"><i class="val">45.66%</i></span>
                                </div>
                            </div>
                            <div class="tot_vote">
                                <div  class="pull-left">Total Votes : 5,098,927</div>
                            </div>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td width="30%"><div class="ele_symbol ">
                            <img src="http://www.adaderana.lk/general-election-2015/assets/images/unp-gen-elec-15.jpg" class="img-responsive" alt="UNP">
                        </div>
                        <div class="ele_symbol_text">UNP</div>
                    </td>

                    <td>
                        <div class="candi_progress">
                            <div class="progress skill-bar">
                                <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="45.66" aria-valuemin="0" aria-valuemax="100" style="background-color: blue">
                                    <span class="skill"><i class="val">45.66%</i></span>
                                </div>
                            </div>
                            <div class="tot_vote">
                                <div  class="pull-left">Total Votes : 5,098,927</div>
                            </div>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td width="30%"><div class="ele_symbol ">
                            <img src="http://www.adaderana.lk/general-election-2015/assets/images/unp-gen-elec-15.jpg" class="img-responsive" alt="UNP">
                        </div>
                        <div class="ele_symbol_text">UNP</div>
                    </td>

                    <td>
                        <div class="candi_progress">
                            <div class="progress skill-bar">
                                <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="45.66" aria-valuemin="0" aria-valuemax="100" style="background-color: blue">
                                    <span class="skill"><i class="val">45.66%</i></span>
                                </div>
                            </div>
                            <div class="tot_vote">
                                <div  class="pull-left">Total Votes : 5,098,927</div>
                            </div>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td width="30%"><div class="ele_symbol ">
                            <img src="http://www.adaderana.lk/general-election-2015/assets/images/unp-gen-elec-15.jpg" class="img-responsive" alt="UNP">
                        </div>
                        <div class="ele_symbol_text">UNP</div>
                    </td>

                    <td>
                        <div class="candi_progress">
                            <div class="progress skill-bar">
                                <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="45.66" aria-valuemin="0" aria-valuemax="100" style="background-color: blue">
                                    <span class="skill"><i class="val">45.66%</i></span>
                                </div>
                            </div>
                            <div class="tot_vote">
                                <div  class="pull-left">Total Votes : 5,098,927</div>
                            </div>
                        </div>
                    </td>
                </tr>

                </tbody>
            </table>

            <table class="table table-striped">
                <thead>
                <h4>Colombo - Borella</h4>
                </thead>
                <tbody>

                <tr>

                    <td width="30%"><div class="ele_symbol ">
                            <img src="http://www.adaderana.lk/general-election-2015/assets/images/unp-gen-elec-15.jpg" class="img-responsive" alt="UNP">
                        </div>
                        <div class="ele_symbol_text">UNP</div>
                    </td>

                    <td>
                        <div class="candi_progress">
                            <div class="progress skill-bar">
                                <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="45.66" aria-valuemin="0" aria-valuemax="100" style="background-color: blue">
                                    <span class="skill"><i class="val">45.66%</i></span>
                                </div>
                            </div>
                            <div class="tot_vote">
                                <div  class="pull-left">Total Votes : 5,098,927</div>
                            </div>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td width="30%"><div class="ele_symbol ">
                            <img src="http://www.adaderana.lk/general-election-2015/assets/images/unp-gen-elec-15.jpg" class="img-responsive" alt="UNP">
                        </div>
                        <div class="ele_symbol_text">UNP</div>
                    </td>

                    <td>
                        <div class="candi_progress">
                            <div class="progress skill-bar">
                                <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="45.66" aria-valuemin="0" aria-valuemax="100" style="background-color: blue">
                                    <span class="skill"><i class="val">45.66%</i></span>
                                </div>
                            </div>
                            <div class="tot_vote">
                                <div  class="pull-left">Total Votes : 5,098,927</div>
                            </div>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td width="30%"><div class="ele_symbol ">
                            <img src="http://www.adaderana.lk/general-election-2015/assets/images/unp-gen-elec-15.jpg" class="img-responsive" alt="UNP">
                        </div>
                        <div class="ele_symbol_text">UNP</div>
                    </td>

                    <td>
                        <div class="candi_progress">
                            <div class="progress skill-bar">
                                <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="45.66" aria-valuemin="0" aria-valuemax="100" style="background-color: blue">
                                    <span class="skill"><i class="val">45.66%</i></span>
                                </div>
                            </div>
                            <div class="tot_vote">
                                <div  class="pull-left">Total Votes : 5,098,927</div>
                            </div>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td width="30%"><div class="ele_symbol ">
                            <img src="http://www.adaderana.lk/general-election-2015/assets/images/unp-gen-elec-15.jpg" class="img-responsive" alt="UNP">
                        </div>
                        <div class="ele_symbol_text">UNP</div>
                    </td>

                    <td>
                        <div class="candi_progress">
                            <div class="progress skill-bar">
                                <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="45.66" aria-valuemin="0" aria-valuemax="100" style="background-color: blue">
                                    <span class="skill"><i class="val">45.66%</i></span>
                                </div>
                            </div>
                            <div class="tot_vote">
                                <div  class="pull-left">Total Votes : 5,098,927</div>
                            </div>
                        </div>
                    </td>
                </tr>

                </tbody>
            </table>
            <div style="width: 100%;height:150px;background: #ccc;text-align: center;margin: 0px;padding: 0px">Ad space</div>
            <h2> Recent  Results</h2>
            <br>
            <table class="table table-striped">
                <thead>
                <h4>Colombo - Borella</h4>
                </thead>
                <tbody>

                <tr>

                    <td width="30%"><div class="ele_symbol ">
                            <img src="http://www.adaderana.lk/general-election-2015/assets/images/unp-gen-elec-15.jpg" class="img-responsive" alt="UNP">
                        </div>
                        <div class="ele_symbol_text">UNP</div>
                    </td>

                    <td>
                        <div class="candi_progress">
                            <div class="progress skill-bar">
                                <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="45.66" aria-valuemin="0" aria-valuemax="100" style="background-color: blue">
                                    <span class="skill"><i class="val">45.66%</i></span>
                                </div>
                            </div>
                            <div class="tot_vote">
                                <div  class="pull-left">Total Votes : 5,098,927</div>
                            </div>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td width="30%"><div class="ele_symbol ">
                            <img src="http://www.adaderana.lk/general-election-2015/assets/images/unp-gen-elec-15.jpg" class="img-responsive" alt="UNP">
                        </div>
                        <div class="ele_symbol_text">UNP</div>
                    </td>

                    <td>
                        <div class="candi_progress">
                            <div class="progress skill-bar">
                                <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="45.66" aria-valuemin="0" aria-valuemax="100" style="background-color: blue">
                                    <span class="skill"><i class="val">45.66%</i></span>
                                </div>
                            </div>
                            <div class="tot_vote">
                                <div  class="pull-left">Total Votes : 5,098,927</div>
                            </div>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td width="30%"><div class="ele_symbol ">
                            <img src="http://www.adaderana.lk/general-election-2015/assets/images/unp-gen-elec-15.jpg" class="img-responsive" alt="UNP">
                        </div>
                        <div class="ele_symbol_text">UNP</div>
                    </td>

                    <td>
                        <div class="candi_progress">
                            <div class="progress skill-bar">
                                <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="45.66" aria-valuemin="0" aria-valuemax="100" style="background-color: blue">
                                    <span class="skill"><i class="val">45.66%</i></span>
                                </div>
                            </div>
                            <div class="tot_vote">
                                <div  class="pull-left">Total Votes : 5,098,927</div>
                            </div>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td width="30%"><div class="ele_symbol">
                            <img src="http://www.adaderana.lk/general-election-2015/assets/images/unp-gen-elec-15.jpg" class="img-responsive" alt="UNP">
                        </div>
                        <div class="ele_symbol_text">UNP</div>
                    </td>

                    <td>
                        <div class="candi_progress">
                            <div class="progress skill-bar">
                                <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="45.66" aria-valuemin="0" aria-valuemax="100" style="background-color: blue">
                                    <span class="skill"><i class="val">45.66%</i></span>
                                </div>
                            </div>
                            <div class="tot_vote">
                                <div  class="pull-left">Total Votes : 5,098,927</div>
                            </div>
                        </div>
                    </td>
                </tr>

                </tbody>
            </table>

            <table class="table table-striped">
                <thead>
                <h4>Colombo - Borella</h4>
                </thead>
                <tbody>

                <tr>

                    <td width="30%"><div class="ele_symbol ">
                            <img src="http://www.adaderana.lk/general-election-2015/assets/images/unp-gen-elec-15.jpg" class="img-responsive" alt="UNP">
                        </div>
                        <div class="ele_symbol_text">UNP</div>
                    </td>

                    <td>
                        <div class="candi_progress">
                            <div class="progress skill-bar">
                                <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="45.66" aria-valuemin="0" aria-valuemax="100" style="background-color: blue">
                                    <span class="skill"><i class="val">45.66%</i></span>
                                </div>
                            </div>
                            <div class="tot_vote">
                                <div  class="pull-left">Total Votes : 5,098,927</div>
                            </div>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td width="30%"><div class="ele_symbol ">
                            <img src="http://www.adaderana.lk/general-election-2015/assets/images/unp-gen-elec-15.jpg" class="img-responsive" alt="UNP">
                        </div>
                        <div class="ele_symbol_text">UNP</div>
                    </td>

                    <td>
                        <div class="candi_progress">
                            <div class="progress skill-bar">
                                <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="45.66" aria-valuemin="0" aria-valuemax="100" style="background-color: blue">
                                    <span class="skill"><i class="val">45.66%</i></span>
                                </div>
                            </div>
                            <div class="tot_vote">
                                <div  class="pull-left">Total Votes : 5,098,927</div>
                            </div>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td width="30%"><div class="ele_symbol ">
                            <img src="http://www.adaderana.lk/general-election-2015/assets/images/unp-gen-elec-15.jpg" class="img-responsive" alt="UNP">
                        </div>
                        <div class="ele_symbol_text">UNP</div>
                    </td>

                    <td>
                        <div class="candi_progress">
                            <div class="progress skill-bar">
                                <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="45.66" aria-valuemin="0" aria-valuemax="100" style="background-color: blue">
                                    <span class="skill"><i class="val">45.66%</i></span>
                                </div>
                            </div>
                            <div class="tot_vote">
                                <div  class="pull-left">Total Votes : 5,098,927</div>
                            </div>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td width="30%"><div class="ele_symbol">
                            <img src="http://www.adaderana.lk/general-election-2015/assets/images/unp-gen-elec-15.jpg" class="img-responsive" alt="UNP">
                        </div>
                        <div class="ele_symbol_text">UNP</div>
                    </td>

                    <td>
                        <div class="candi_progress">
                            <div class="progress skill-bar">
                                <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="45.66" aria-valuemin="0" aria-valuemax="100" style="background-color: blue">
                                    <span class="skill"><i class="val">45.66%</i></span>
                                </div>
                            </div>
                            <div class="tot_vote">
                                <div  class="pull-left">Total Votes : 5,098,927</div>
                            </div>
                        </div>
                    </td>
                </tr>

                </tbody>
            </table>
            <table class="table table-striped">
                <thead>
                <h4>Colombo - Borella</h4>
                </thead>
                <tbody>

                <tr>

                    <td width="30%"><div class="ele_symbol ">
                            <img src="http://www.adaderana.lk/general-election-2015/assets/images/unp-gen-elec-15.jpg" class="img-responsive" alt="UNP">
                        </div>
                        <div class="ele_symbol_text">UNP</div>
                    </td>

                    <td>
                        <div class="candi_progress">
                            <div class="progress skill-bar">
                                <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="45.66" aria-valuemin="0" aria-valuemax="100" style="background-color: blue">
                                    <span class="skill"><i class="val">45.66%</i></span>
                                </div>
                            </div>
                            <div class="tot_vote">
                                <div  class="pull-left">Total Votes : 5,098,927</div>
                            </div>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td width="30%"><div class="ele_symbol ">
                            <img src="http://www.adaderana.lk/general-election-2015/assets/images/unp-gen-elec-15.jpg" class="img-responsive" alt="UNP">
                        </div>
                        <div class="ele_symbol_text">UNP</div>
                    </td>

                    <td>
                        <div class="candi_progress">
                            <div class="progress skill-bar">
                                <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="45.66" aria-valuemin="0" aria-valuemax="100" style="background-color: blue">
                                    <span class="skill"><i class="val">45.66%</i></span>
                                </div>
                            </div>
                            <div class="tot_vote">
                                <div  class="pull-left">Total Votes : 5,098,927</div>
                            </div>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td width="30%"><div class="ele_symbol ">
                            <img src="http://www.adaderana.lk/general-election-2015/assets/images/unp-gen-elec-15.jpg" class="img-responsive" alt="UNP">
                        </div>
                        <div class="ele_symbol_text">UNP</div>
                    </td>

                    <td>
                        <div class="candi_progress">
                            <div class="progress skill-bar">
                                <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="45.66" aria-valuemin="0" aria-valuemax="100" style="background-color: blue">
                                    <span class="skill"><i class="val">45.66%</i></span>
                                </div>
                            </div>
                            <div class="tot_vote">
                                <div  class="pull-left">Total Votes : 5,098,927</div>
                            </div>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td width="30%"><div class="ele_symbol">
                            <img src="http://www.adaderana.lk/general-election-2015/assets/images/unp-gen-elec-15.jpg" class="img-responsive" alt="UNP">
                        </div>
                        <div class="ele_symbol_text">UNP</div>
                    </td>

                    <td>
                        <div class="candi_progress">
                            <div class="progress skill-bar">
                                <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="45.66" aria-valuemin="0" aria-valuemax="100" style="background-color: blue">
                                    <span class="skill"><i class="val">45.66%</i></span>
                                </div>
                            </div>
                            <div class="tot_vote">
                                <div  class="pull-left">Total Votes : 5,098,927</div>
                            </div>
                        </div>
                    </td>
                </tr>

                </tbody>
            </table>
            <div style="width: 100%;height:300px;background: #ccc;text-align: center;margin: 0px;padding: 0px">Ad space</div>
</div>


<?php
include_once 'Model/dbConfig.php';
$query="SELECT * FROM file_name ORDER BY date DESC limit 2 ";
$result=mysql_query($query);
while ($row=mysql_fetch_assoc($result)){
    $url="electionadmin/Files/".$row['file_name'];
    $xml = simplexml_load_file("electionadmin/Files/".$row['file_name']) or die("Error: Cannot create object");

    foreach ($xml->summary as $vots) {
        $vv= $vots->valid_votes;
        $vv = intval(preg_replace('/[^\d.]/', '', $vv));

        $vj= $vots->rejected;
        $vj = intval(preg_replace('/[^\d.]/', '', $vj));

        $vvc=(int)$vv;
        $vjc=(int)$vj;

        $pollv=$vvc+$vjc;
        $vvp=($vvc/$pollv)*100;
        $pollv=number_format($pollv);


    }
}
?>

<!-- Bootstrap core JavaScript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script>window.jQuery || document.write('<script src="../../assets/js/vendor/jquery.min.js"><\/script>')</script>
<script src="../js/bootstrap.min.js"></script>
<script>
    $(document).ready(function() {
        $('.progress .progress-bar').css("width",
            function() {
                return $(this).attr("aria-valuenow") + "%";
            }
        )
    });

</script>
<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
<script src="../../assets/js/ie10-viewport-bug-workaround.js"></script>
</body>
</html>