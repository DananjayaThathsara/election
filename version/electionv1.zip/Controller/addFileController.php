<?php
error_reporting(1);
include_once '../Model/dbConfig.php';
include_once('../Model/addFileClass.php');
include_once('../Model/fileUploadClass.php');
//Check posting data ------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    //relative path
    //Database Insert part Start

    if (trim($_POST['d_id']) == null || trim($_POST['c_id']) == null) {
        echo('<div class="alert alert-danger  alert-error">
                        <a href="#" class="close" data-dismiss="alert">&times;</a>
                        <strong>Error!</strong> Please Enter Required Feilds.
                    </div>');
    } else {
        $addeObj = new addFileClass();
        $fileObj=new fileUploadClass();
        try {
            $c_id = $_POST['c_id'];
            $d_id = $_POST['d_id'];
            $date = date('Y-m-d h:i:s');
            $status = 'active';

            if($_FILES['file_name']['name'] == null){
                echo('<div class="alert alert-danger  alert-error">
                        <a href="#" class="close" data-dismiss="alert">&times;</a>
                        <strong>Error!</strong> Please choose council file.
                    </div>');
            }else{
                $uploaddir = 'Files/';
                $fileObj->singleFileUpload($_FILES['file_name']['name'], $_FILES['file_name']['tmp_name'], $uploaddir);
                $addeObj->setFileName($fileObj->getFilename());
            }

            $addeObj->setCId($c_id);
            $addeObj->setDId($d_id);
            $addeObj->setDate($date);
            $addeObj->setStatus($status);

            if ($addeObj->addFile()) {
                echo('<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>  
<strong>Success!</strong>Council details are added..</div>');
            }
        } catch (Exception $ex) {
            echo('<div class="alert alert-danger  alert-error">
                        <a href="#" class="close" data-dismiss="alert">&times;</a>
                        <strong>Error!</strong>' . $ex->getMessage() . '
                    </div>');
        }
    }

}
?>
