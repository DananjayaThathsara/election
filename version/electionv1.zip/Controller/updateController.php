<?php
error_reporting(1);
include_once '../Model/dbConfig.php';
include_once('../Model/updateClass.php');
include_once('../Model/encryption.php');
//Check posting data ------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    //relative path
    //Database Insert part Start

    if($_POST['controller']=='updateUserProfile'){

    if (trim($_POST['user_name']) == null || trim($_POST['user_email']) == null) {
        echo('<div class="alert alert-danger  alert-error">
                        <a href="#" class="close" data-dismiss="alert">&times;</a>
                        <strong>Error!</strong> Please Enter Required Feilds.
                    </div>');
    } else {
        $upObj = new updateClass();
        $encObj = new encryption();
        try {
            $user_id = $_POST['user_id'];
            $date = $_POST['date'];

            $user_name = mysql_real_escape_string($_POST['user_name']);
            $user_email = mysql_real_escape_string($_POST['user_email']);
            if ($_POST['user_pword'] != '') {
                $user_pword = mysql_real_escape_string($_POST['user_pword']);
                $user_pword_en = $encObj->encode($user_pword);

            } else {
                $user_pword_en = $_POST['current_password'];

            }
            $upObj->setUserName($user_name);
            $upObj->setUserEmail($user_email);
            $upObj->setUserPword($user_pword_en);
            $upObj->setId($user_id);
            $upObj->setDate($date);

            if ($upObj->updateUserProfile()) {

                echo('<div class="alert alert-success">
 <a href="#" class="close" data-dismiss="alert">&times;</a>
  <strong>Success!</strong> Your Profile is updated..
</div>');
            }

        } catch (Exception $ex) {
            echo('<div class="alert alert-danger  alert-error">
                        <a href="#" class="close" data-dismiss="alert">&times;</a>
                        <strong>Error!</strong>' . $ex->getMessage() . '
                    </div>');

        }
    }
}
    if($_POST['controller']=='updateContactProfile'){

        if (trim($_POST['c_name']) == null || trim($_POST['c_email']) == null|| trim($_POST['c_phone']) == null|| trim($_POST['c_group']) == null) {
            echo('<div class="alert alert-danger  alert-error">
                        <a href="#" class="close" data-dismiss="alert">&times;</a>
                        <strong>Error!</strong> Please Enter Required Feilds.
                    </div>');
        } else {
            $upObj = new updateClass();

            try {
                $c_id = $_POST['c_id'];
                $date = $_POST['date'];


                $upObj->setCName($_POST['c_name']);
                $upObj->setCEmail($_POST['c_email']);
                $upObj->setCPhone($_POST['c_phone']);
                $upObj->setCGroup($_POST['c_group']);
                $upObj->setCRemarks($_POST['c_remarks']);
                $upObj->setCId($_POST['c_id']);


                if ($upObj->updateContactUserDetails()) {

                    echo('<div class="alert alert-success">
 <a href="#" class="close" data-dismiss="alert">&times;</a>
  <strong>Success!</strong> Contact Details are updated..
</div>');
                }

            } catch (Exception $ex) {
                echo('<div class="alert alert-danger  alert-error">
                        <a href="#" class="close" data-dismiss="alert">&times;</a>
                        <strong>Error!</strong>' . $ex->getMessage() . '
                    </div>');

            }
        }
    }

}
?>
