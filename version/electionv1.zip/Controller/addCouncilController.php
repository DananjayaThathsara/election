<?php
error_reporting(1);
include_once '../Model/dbConfig.php';
include_once('../Model/addConuncilClass.php');
//Check posting data ------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    //relative path
    //Database Insert part Start

    if (trim($_POST['c_code']) == null || trim($_POST['c_name']) == null || trim($_POST['d_id']) == null) {
        echo('<div class="alert alert-danger  alert-error">
                        <a href="#" class="close" data-dismiss="alert">&times;</a>
                        <strong>Error!</strong> Please Enter Required Feilds.
                    </div>');
    } else {
        $addeObj = new addConuncilClass();

        try {
            $c_code = $_POST['c_code'];
            $c_name = $_POST['c_name'];
            $d_id = $_POST['d_id'];
            $date = date('Y-m-d h:i:s');
            $c_status = 'active';

            $addeObj->setCCode($c_code);
            $addeObj->setCName($c_name);
            $addeObj->setDId($d_id);
            $addeObj->setDate($date);
            $addeObj->setStatus($c_status);

            if ($addeObj->addCouncil()) {
                echo('<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>  
<strong>Success!</strong>Council details are added..</div>');
            }
        } catch (Exception $ex) {
            echo('<div class="alert alert-danger  alert-error">
                        <a href="#" class="close" data-dismiss="alert">&times;</a>
                        <strong>Error!</strong>' . $ex->getMessage() . '
                    </div>');
        }
    }

}
?>
