<!DOCTYPE html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="">

    <title>Election</title>
    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link href="css/style.css" rel="stylesheet">

</head>
<html>
<body>
<div class="container">
    <div class="row">
        <img src="img/top.png" class="img-responsive" width="100%">
    </div>
    <div class="row">
        <div style="width: 100%;height: 80px;background: #ccc;vertical-align: middle;text-align: center">Ad Space</div>
    </div>
    <div class="row">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                <li class="breadcrumb-item"><a href="distrctInner.php">Local Authority</a></li>
                <li class="breadcrumb-item active" aria-current="page">Result</li>
            </ol>
        </nav>
        <h2>Colombo - Sethaawaka</h2>
        <table class="table table-striped">
            <thead>
            <tr>
                <th>Party</th>
                <th>Votes</th>
                <th>Precentage</th>
                <th>Selected Members</th>
                <th>Calculated Members</th>
                <th>Total Members</th>
            </tr>
            </thead>
            <tbody>
            <tr>
                <td>
                    <div class="ele_symbol ">
                        <img src="http://www.adaderana.lk/general-election-2015/assets/images/unp-gen-elec-15.jpg" width="30" height="30" class="img-responsive" alt="UNP">
                    </div>
                    <div class="ele_symbol_text" style="font-size: 14px">United National Party</div>
                </td>
                <td>5,098,927</td>
                <td>45.66%</td>
                <td>5</td>
                <td>6</td>
                <td>11</td>
            </tr>
            <tr>
                <td>
                    <div class="ele_symbol ">
                        <img src="http://www.adaderana.lk/general-election-2015/assets/images/unp-gen-elec-15.jpg" width="30" height="30" class="img-responsive" alt="UNP">
                    </div>
                    <div class="ele_symbol_text" style="font-size: 14px">United National Party</div>
                </td>
                <td>5,098,927</td>
                <td>45.66%</td>
                <td>5</td>
                <td>6</td>
                <td>11</td>
            </tr>
            <tr>
                <td>
                    <div class="ele_symbol ">
                        <img src="http://www.adaderana.lk/general-election-2015/assets/images/unp-gen-elec-15.jpg" width="30" height="30" class="img-responsive" alt="UNP">
                    </div>
                    <div class="ele_symbol_text" style="font-size: 14px">United National Party</div>
                </td>
                <td>5,098,927</td>
                <td>45.66%</td>
                <td>5</td>
                <td>6</td>
                <td>11</td>
            </tr>
            <tr>
                <td>
                    <div class="ele_symbol ">
                        <img src="http://www.adaderana.lk/general-election-2015/assets/images/unp-gen-elec-15.jpg" width="30" height="30" class="img-responsive" alt="UNP">
                    </div>
                    <div class="ele_symbol_text" style="font-size: 14px">United National Party</div>
                </td>
                <td>5,098,927</td>
                <td>45.66%</td>
                <td>5</td>
                <td>6</td>
                <td>11</td>
            </tr>
            <tr>
                <td>
                    <div class="ele_symbol ">
                        <img src="http://www.adaderana.lk/general-election-2015/assets/images/unp-gen-elec-15.jpg" width="30" height="30" class="img-responsive" alt="UNP">
                    </div>
                    <div class="ele_symbol_text" style="font-size: 14px">United National Party</div>
                </td>
                <td>5,098,927</td>
                <td>45.66%</td>
                <td>5</td>
                <td>6</td>
                <td>11</td>
            </tr>
            </tbody>
        </table>
        <div class="col-md-8">
            <div style="width: 100%;height:90px;background: #ccc;text-align: center;margin: 0px;padding: 0px">Ad space</div>
            <br>
            <table class="table table-bordered table-hover">
                <tbody>
                <tr>
                    <th><b>VALID</b></th>
                    <td>1,208,899</td>
                    <td>96.54%</td>
                </tr>
                <tr>
                    <th><b>REJECTED</b></th>
                    <td>43,372</td>
                    <td>3.46%</td>
                </tr>
                <tr>
                    <th><b>POLLED</b></th>
                    <td>1,252,271</td>
                    <td>78.93%</td>
                </tr>
                <tr>
                    <th><b>ELECTORS</b></th>
                    <td>1,586,598</td>
                    <td>&nbsp;</td>
                </tr>
                </tbody>
            </table>
            <br>
            <div style="width: 100%;height:90px;background: #ccc;text-align: center;margin: 0px;padding: 0px">Ad space</div>
        </div>
        <div class="col-md-4">
            <div style="width: 100%;height:90px;background: #ccc;text-align: center;margin: 0px;padding: 0px">Ad space</div>
                <h2>Polling Loacal Authority</h2>

                <table class="table table-striped">
                    <thead>
                    <tr>
                        <th>District</th>
                        <th style="text-align: center">Action</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                    include_once 'Model/dbConfig.php';
                    $query="SELECT * FROM district LIMIT 13";
                    $result=mysql_query($query);

                    while ($row=mysql_fetch_assoc($result)){

                    ?>
                    <tr>
                        <td>
                           <?php echo $row['d_name'];?>
                        </td>
                        <td style="text-align: center"><a href="">View</a></td>
                    </tr>
               <?php }?>

                    </tbody>
                </table>

       </div>



<?php
include_once 'Model/dbConfig.php';
$query="SELECT * FROM file_name ORDER BY date DESC limit 2 ";
$result=mysql_query($query);
while ($row=mysql_fetch_assoc($result)){
    $url="electionadmin/Files/".$row['file_name'];
    $xml = simplexml_load_file("electionadmin/Files/".$row['file_name']) or die("Error: Cannot create object");

    foreach ($xml->summary as $vots) {
        $vv= $vots->valid_votes;
        $vv = intval(preg_replace('/[^\d.]/', '', $vv));

        $vj= $vots->rejected;
        $vj = intval(preg_replace('/[^\d.]/', '', $vj));

        $vvc=(int)$vv;
        $vjc=(int)$vj;

        $pollv=$vvc+$vjc;
        $vvp=($vvc/$pollv)*100;
        $pollv=number_format($pollv);


    }
}
?>

<!-- Bootstrap core JavaScript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

<script src="../js/bootstrap.min.js"></script>
<script>
    $(document).ready(function() {
        $('.progress .progress-bar').css("width",
            function() {
                return $(this).attr("aria-valuenow") + "%";
            }
        )
    });

</script>

</body>
</html>