
<?php
include '../Model/dbConfig.php';
$council= $_REQUEST['council'];
?>
<div class="form-group">
    <label>Council</label>
    <select class="form-control" name="c_id">
        <option disabled selected>Select Council</option>
        <?php
        $query="SELECT * FROM council WHERE d_id='$council' ORDER BY c_name ASC";
        $result=mysql_query($query);
        if($result){
            while ($row=mysql_fetch_assoc($result)){
                ?>
                <option value="<?php echo $row['c_id'];?>"><?php echo $row['c_name'];?> - <?php echo $row['c_code'];?></option>
            <?php }
        }?>
    </select>
</div>