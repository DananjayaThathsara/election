<?php

/**
 * Created by PhpStorm.
 * User: Nethweb
 * Date: 10/27/2017
 * Time: 4:40 PM
 */
class deleteClass
{
private $c_id;
private $c_status;

    /**
     * @return mixed
     */
    public function getCStatus()
    {
        return $this->c_status;
    }

    /**
     * @param mixed $c_status
     */
    public function setCStatus($c_status)
    {
        $this->c_status = $c_status;
    }

    /**
     * @return mixed
     */
    public function getCId()
    {
        return $this->c_id;
    }

    /**
     * @param mixed $c_id
     */
    public function setCId($c_id)
    {
        $this->c_id = $c_id;
    }

    public function deleteContactUserDetails(){
        $query="UPDATE contact_details SET c_status='".$this->getCStatus()."' WHERE c_id='".$this->getCId()."'";
        $result=mysql_query($query);
        if($result){
            return true;
        }
        else{
            throw new Exception(mysql_error());
        }
    }

}