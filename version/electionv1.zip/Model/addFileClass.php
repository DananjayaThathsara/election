<?php

/**
 * Created by PhpStorm.
 * User: Nethweb
 * Date: 1/30/2018
 * Time: 9:59 AM
 */
class addFileClass
{
    private $id;
    private $d_id;
    private $c_id;
    private $file_name;
    private $date;
    private $status;
    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param mixed $id
     */
    public function setId($id)
    {
        $this->id = $id;
    }

    /**
     * @return mixed
     */
    public function getDId()
    {
        return $this->d_id;
    }

    /**
     * @param mixed $d_id
     */
    public function setDId($d_id)
    {
        $this->d_id = $d_id;
    }

    /**
     * @return mixed
     */
    public function getCId()
    {
        return $this->c_id;
    }

    /**
     * @param mixed $c_id
     */
    public function setCId($c_id)
    {
        $this->c_id = $c_id;
    }

    /**
     * @return mixed
     */
    public function getFileName()
    {
        return $this->file_name;
    }

    /**
     * @param mixed $file_name
     */
    public function setFileName($file_name)
    {
        $this->file_name = $file_name;
    }

    /**
     * @return mixed
     */
    public function getDate()
    {
        return $this->date;
    }

    /**
     * @param mixed $date
     */
    public function setDate($date)
    {
        $this->date = $date;
    }

    /**
     * @return mixed
     */
    public function getStatus()
    {
        return $this->status;
    }

    /**
     * @param mixed $status
     */
    public function setStatus($status)
    {
        $this->status = $status;
    }
    public function checkFile(){
        $query = "SELECT * FROM file_name WHERE  c_id='".$this->getCId()."'";
        $result=mysql_query($query);
        $count=mysql_num_rows($result);
        if($count >=1){

            return true;
        }else{
            return false;
        }
    }
    public function addFile()
    {
if($this->checkFile()){
    echo('<div class="alert alert-danger  alert-error">
                        <a href="#" class="close" data-dismiss="alert">&times;</a>
                        <strong>Error!</strong>This council Result file is already uploaded.
                    </div>');}else{
            $query = "INSERT INTO file_name (d_id,c_id,file_name,date,status) VALUES('" . $this->getDId() . "','" . $this->getCId(). "',
            '" . $this->getFileName()."','" . $this->getDate()."','" . $this->getStatus()."') ";
            $result=mysql_query($query);
            if($result){
                return true;
            }else{
                throw new Exception(mysql_error());
            }

        }
    }
}