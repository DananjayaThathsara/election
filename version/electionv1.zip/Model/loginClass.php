<?php
error_reporting(0);
if (!isset($_SESSION)) {
    session_start();
}
include('dbConfig.php'); //database
include('encryption.php'); //encryption class

class loginClass {
    private $confirm_id;
    private $user_name;
    private $user_email;
    private $user_pword;
    private $date;

    /**
     * @return mixed
     */
    public function getConfirmId()
    {
        return $this->confirm_id;
    }

    /**
     * @param mixed $confirm_id
     */
    public function setConfirmId($confirm_id)
    {
        $this->confirm_id = $confirm_id;
    }

    /**
     * @return mixed
     */
    public function getUserName()
    {
        return $this->user_name;
    }

    /**
     * @param mixed $user_name
     */
    public function setUserName($user_name)
    {
        $this->user_name = $user_name;
    }

    /**
     * @return mixed
     */
    public function getUserEmail()
    {
        return $this->user_email;
    }

    /**
     * @param mixed $user_email
     */
    public function setUserEmail($user_email)
    {
        $this->user_email = $user_email;
    }

    /**
     * @return mixed
     */
    public function getUserPword()
    {
        return $this->user_pword;
    }

    /**
     * @param mixed $user_pword
     */
    public function setUserPword($user_pword)
    {
        $this->user_pword = $user_pword;
    }

    /**
     * @return mixed
     */
    public function getDate()
    {
        return $this->date;
    }

    /**
     * @param mixed $date
     */
    public function setDate($date)
    {
        $this->date = $date;
    }
    public function checkCredintial() {
        $ecryptObj = new encryption();
        $query = "SELECT * FROM registered_user WHERE user_email='" . $this->getUserEmail() . "'  AND user_pword='" . $ecryptObj->encode($this->getUserPword()) ."'";

        $result = mysql_query($query);
        $count = mysql_num_rows($result);
        if ($count >= 1) {
            while ($row = mysql_fetch_array($result)) {
                $_SESSION['system_logged_status'] = 'true'; //user is logged.
                $_SESSION['system_logged_id']=$row['id'];
                $_SESSION['system_logged_email'] = $row['user_email']; //user email
                $_SESSION['system_logged_uname'] = $row['user_name']; //username

                $_SESSION['start'] = time(); // Taking now logged in time.
                // Ending a session in 120 minutes from the starting time.
                $_SESSION['expire'] = $_SESSION['start'] + (120 * 60);
                return true; //user is a active user and email is verified
            }//end while
        } else {
            //wrong password
            throw new Exception("Sorry, password or username incorrect.");
        }
    }

  

}
