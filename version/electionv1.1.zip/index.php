<!DOCTYPE html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../favicon.ico">

    <title>Election</title>
    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link href="css/style.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="navbar.css" rel="stylesheet">
    <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
    <!--[if lt IE 9]>
    <script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
    <script src="../../assets/js/ie-emulation-modes-warning.js"></script>
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<html>
<body>
<div class="container">
    <div class="row">
        <img src="img/top.png" class="img-responsive" width="100%">
    </div>
    <div class="row">
        <div style="width: 100%;height: 80px;background: #ccc;vertical-align: middle;text-align: center">Ad Space</div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="col-md-6">
                <h2 style="font-family: 'malithi web'">සමස්ත ප්‍රතිපලය</h2><h3 style="font-family: 'malithi web'">(මෙතෙක් ලැබුණු නිල ප්‍රතිපල අනුව)</h3>
                <table class="table table-striped">
                    <thead>
                    </thead>
                    <tbody>

                    <?php
                    include_once 'Model/dbConfig.php';
                    $queryall="SELECT SUM(tot_valid_votes) as tot_valid_votes,d_id,l_id FROM sammary";

                    $resultall=mysql_query($queryall);
                    $tot_valid_votes;
                    if($resultall){
                        while ($rowall=mysql_fetch_assoc($resultall)) {
                            $tot_valid_votes = $rowall['tot_valid_votes'];
                        }}
                            ?>
                        <?php
                        $queryParty="SELECT SUM(lp1.p_votes) as tot_p_votes,pa1.p_name_short,pa1.p_image_name,pa1.p_name,pa1.p_color,pa1.p_id
                                        FROM la_party as lp1
                                        LEFT  JOIN party as pa1 ON lp1.p_id=pa1.p_id  GROUP BY lp1.p_id ORDER BY lp1.p_votes DESC LIMIT 5";
                        $resultParty=mysql_query($queryParty);
                        if($resultParty){
                            while ($rowParty=mysql_fetch_assoc($resultParty)) {
                           $precentageParty=($rowParty['tot_p_votes']/$tot_valid_votes)*100
                            ?>
                            <tr>
                                <td width="30%"><div class="ele_symbol ">
                                        <img src="party_logo/<?php echo $rowParty['p_image_name'];?>" class="img-responsive">
                                    </div>
                                    <div class="ele_symbol_text"><?php echo $rowParty['p_name_short'];?></div>
                                </td>
                                <td>
                                    <div class="candi_progress">
                                        <div class="progress skill-bar">
                                            <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="<?php echo $precentageParty;?>" aria-valuemin="0" aria-valuemax="100" style="background-color:<?php echo $rowParty['p_color'];?>">

                                            </div>
                                        </div>
                                        <div class="tot_vote">
                                            <div  class="pull-right"><b>Total Votes : <?php echo number_format( $rowParty['tot_p_votes']);?></b></div>
                                            <div  class="pull-left"><b><?php echo round($precentageParty,2);?> %</b></div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
<?php }}?>
                    </tbody>
                </table>
            </div>
            <div class="col-md-6">
                <h2 style="margin-bottom:26px;font-family: 'malithi web'">නවතම ඡන්ද ප්‍රතිපලය</h2>

                <table class="table table-striped">
                    <thead>
                    <?php
                    $querytitle="SELECT d_id,l_id FROM la_party ORDER BY date DESC LIMIT 1 ";
                    $resulttitle=mysql_query($querytitle);
                    if($resulttitle){

                    while ($rowtitle=mysql_fetch_assoc($resulttitle)){
                        $querytt="SELECT d.d_name,l.l_name 
                        FROM dis d 
                        LEFT JOIN la as l ON d.d_id=l.d_id
                        WHERE l.l_id='".$rowtitle['l_id']."' AND d.d_id='".$rowtitle['d_id']."'
                        ";

                        $resultt=mysql_query($querytt);
                        while ($rowtt=mysql_fetch_assoc($resultt)){

                    ?>
                    <h4><?php echo $rowtt['d_name']?> - <?php echo $rowtt['l_name']?></h4>
                    <?php }?>
                    </thead>
                    <tbody>
                    <?php
$query23="SELECT lp.p_votes,sa.tot_valid_votes,pa.p_name_short,pa.p_image_name,pa.p_name,pa.p_color
FROM la_party as lp 
LEFT JOIN sammary as sa ON lp.d_id = sa.d_id AND lp.l_id = sa.l_id
LEFT JOIN party as pa ON lp.p_id = pa.p_id
WHERE lp.l_id='".$rowtitle['l_id']."' AND lp.d_id='".$rowtitle['d_id']."'
ORDER BY lp.p_votes DESC ,lp.date DESC LIMIT 5
";
               $result23=mysql_query($query23);
                    if($result23){
                    while ($row23=mysql_fetch_assoc($result23)){

                    ?>
                    <tr>
                        <td>
                            <div class="ele_symbol">
                                <img src="party_logo/<?php echo $row23['p_image_name']?>"  class="img-responsive" alt="UNP">
                            </div>
                            <div class="ele_symbol_text" style="font-size: 14px"><?php echo $row23['p_name_short']?></div>
                        </td>

                        <td>
                            <div class="candi_progress">
                                <div class="progress skill-bar">
                                    <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow=" <?php echo ($row23['p_votes']/$row23['tot_valid_votes'])*100 ;?>" aria-valuemin="0" aria-valuemax="100" style="background-color: <?php echo $row23['p_color']; ?>">
                                        <span class="skill"><i class="val"> </i></span>
                                    </div>
                                </div>
                                <div class="tot_vote">
                                    <div  class="pull-right"><b>Votes : <?php echo number_format($row23['p_votes']);?></b></div>
                                    <div  class="pull-left"><b><?php $precentage23=($row23['p_votes']/$row23['tot_valid_votes'])*100;
                                            echo round($precentage23,2) ;?> %</b></div>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <?php }}}}?>

                    </tbody>
                </table>
            </div>
        </div>
        <div class="col-md-8">
                <div style="width: 100%;height: 80px;background: #ccc;text-align: center;margin: 0px;padding: 0px">Ad space</div>
        <h2 style="font-family:'malithi web' ">මේ වන විට දිනා ඇති ආසන ගණන</h2>
            <table class="table table-striped">
                <thead>
                <tr>
                    <th style="text-align: center">Party</th>
                    <th style="text-align: center">Elected Members</th>
                    <th style="text-align: center">Calculated Members</th>
                    <th style="text-align: center">Total Members</th>
                </tr>
                </thead>
                <tbody>
                <?php
                $queryPartyMem="SELECT SUM(lpm.elected_mem) as ele_mem,SUM(lpm.caculated_mem) as cal_mem,sum(lpm.tot_mem) as tot_mem,pa2.p_name_short,pa2.p_image_name,pa2.p_name
                                        FROM la_party_members as lpm
                                        LEFT  JOIN party as pa2 ON lpm.p_id=pa2.p_id GROUP BY lpm.p_id ORDER BY tot_mem DESC LIMIT 5";

                $resultPartyMem=mysql_query($queryPartyMem);
                if($resultPartyMem){
                while ($rowPartyMem=mysql_fetch_assoc($resultPartyMem)) {

                ?>
                <tr>
                    <td width="30%"><div class="ele_symbol ">
                            <img src="party_logo/<?php echo $rowPartyMem['p_image_name'];?>" class="img-responsive" width="30" height="30">
                        </div>
                        <div class="ele_symbol_text"><?php echo $rowPartyMem['p_name_short'];?></div>
                    </td>
                    <td style="text-align: center"><?php echo $rowPartyMem['ele_mem'];?></td>
                    <td style="text-align: center"><?php echo $rowPartyMem['cal_mem'];?></td>
                    <td style="text-align: center"><?php echo  $rowPartyMem['tot_mem'];?></td>
                </tr><?php }}?>
                </tbody>
            </table>
                <h2 style="font-family:'malithi web' ">ඡන්දය පවත්වන දිස්ත්‍රික්ක</h2>
                <table class="table table-striped">
                    <thead>
                    <tr>
                        <th>District</th>
                        <th style="text-align: center">Action</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                    include_once 'Model/dbConfig.php';
                    $query="SELECT * FROM dis";
                    $result=mysql_query($query);

                    while ($row=mysql_fetch_assoc($result)){

                    ?>
                    <tr>
                        <td>
                           <?php echo $row['d_name'];?>
                        </td>
                        <td style="text-align: center"><a href="distrctInner.php?d_id=<?php echo $row['d_id'];?>">View Results</a></td>
                    </tr>
               <?php }?>

                    </tbody>
                </table>

       </div>
        <div class="col-md-4" id="side">
                        <div style="width: 100%;height:150px;background: #ccc;text-align: center;margin: 0px;padding: 0px">Ad space</div>

            <h2 style="font-family: 'malithi web'">පෙර ප්‍රතිපල</h2>
            <br>
            <?php
            $queryrec="SELECT d_id,l_id FROM la_party GROUP  BY  l_id ORDER BY date DESC LIMIT 1,3";
            $resultrec=mysql_query($queryrec);
            if($resultrec){
                while ($rowrec=mysql_fetch_assoc($resultrec)){
                    $d_id=$rowrec['d_id'];
                    $l_id=$rowrec['l_id'];
                    ?>
            <table class="table table-striped">
                <thead>
                    <?php
                    $queryttt="SELECT d.d_name,l.l_name 
                        FROM dis d 
                        LEFT JOIN la as l ON d.d_id=l.d_id
                        WHERE l.l_id='".$l_id."' AND d.d_id='".$d_id."' LIMIT 1
                        ";

                    $resulttt=mysql_query($queryttt);
                    while ($rowttt=mysql_fetch_assoc($resulttt)){

                        ?>
                        <h4><?php echo $rowttt['d_name']?> - <?php echo $rowttt['l_name']?></h4>
                <?php }?>
                </thead>
                <tbody>
                <?php
                $query234="SELECT lp.p_votes,sa.tot_valid_votes,pa.p_name_short,pa.p_image_name,pa.p_name,pa.p_color
FROM la_party as lp 
LEFT JOIN sammary as sa ON lp.d_id = sa.d_id AND lp.l_id = sa.l_id
LEFT JOIN party as pa ON lp.p_id = pa.p_id
WHERE lp.l_id='".$l_id."' AND lp.d_id='".$d_id."'
ORDER BY lp.p_votes DESC ,lp.date DESC LIMIT 4
";
                $result234=mysql_query($query234);
                if($result234){
                while ($row234=mysql_fetch_assoc($result234)){
                    $precentage234=($row234['p_votes']/$row234['tot_valid_votes'])*100;
                ?>
                <tr>
                    <td>
                        <div class="ele_symbol">
                            <img src="party_logo/<?php echo $row234['p_image_name']?>"  class="img-responsive" alt="UNP">
                        </div>
                        <div class="ele_symbol_text" style="font-size: 14px"><?php echo $row234['p_name_short']?></div>
                    </td>

                    <td>
                        <div class="candi_progress">
                            <div class="progress skill-bar">
                                <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow=" <?php echo round($precentage234,2) ;?>" aria-valuemin="0" aria-valuemax="100" style="background-color: <?php echo $row234['p_color']; ?>">
                                    <span class="skill"><i class="val"> </i></span>
                                </div>
                            </div>
                            <div class="tot_vote">
                                <div  class="pull-right"><b>Votes : <?php echo number_format($row234['p_votes']);?></b></div>
                                <div  class="pull-left"><b><?php echo round($precentage234,2) ;?> %</b></div>
                            </div>
                        </div>
                    </td>
                </tr>
             <?php }}?>

                </tbody>
            </table>
            <?php }}?>


            <div style="width: 100%;height:300px;background: #ccc;text-align: center;margin: 0px;padding: 0px">Ad space</div>
</div>


<?php
include_once 'Model/dbConfig.php';
$query="SELECT * FROM file_name ORDER BY date DESC limit 2 ";
$result=mysql_query($query);
while ($row=mysql_fetch_assoc($result)){
    $url="electionadmin/Files/".$row['file_name'];
    $xml = simplexml_load_file("electionadmin/Files/".$row['file_name']) or die("Error: Cannot create object");

    foreach ($xml->summary as $vots) {
        $vv= $vots->valid_votes;
        $vv = intval(preg_replace('/[^\d.]/', '', $vv));

        $vj= $vots->rejected;
        $vj = intval(preg_replace('/[^\d.]/', '', $vj));

        $vvc=(int)$vv;
        $vjc=(int)$vj;

        $pollv=$vvc+$vjc;
        $vvp=($vvc/$pollv)*100;
        $pollv=number_format($pollv);


    }
}
?>

<!-- Bootstrap core JavaScript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script>window.jQuery || document.write('<script src="../../assets/js/vendor/jquery.min.js"><\/script>')</script>
<script src="../js/bootstrap.min.js"></script>
<script>
    $(document).ready(function() {
        $('.progress .progress-bar').css("width",
            function() {
                return $(this).attr("aria-valuenow") + "%";
            }
        )
    });

</script>
<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
<script src="../../assets/js/ie10-viewport-bug-workaround.js"></script>
</body>
</html>