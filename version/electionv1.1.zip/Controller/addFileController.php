<?php
error_reporting(1);
include_once '../Model/dbConfig.php';
include_once('../Model/addFileClass.php');
include_once('../Model/fileUploadClass.php');
//Check posting data ------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    //relative path
    //Database Insert part Start

    if (trim($_POST['d_id']) == null || trim($_POST['l_id']) == null) {
        echo('<div class="alert alert-danger  alert-error">
                        <a href="#" class="close" data-dismiss="alert">&times;</a>
                        <strong>Error!</strong> Please Enter Required Feilds.
                    </div>');
    } else {
        $addeObj = new addFileClass();
        $fileObj=new fileUploadClass();
        try {
            $l_id = $_POST['l_id'];
            $d_id = $_POST['d_id'];
            $date = date('Y-m-d h:i:s');
            $status = 'active';

            if($_FILES['file_name']['name'] == null){
                echo('<div class="alert alert-danger  alert-error">
                        <a href="#" class="close" data-dismiss="alert">&times;</a>
                        <strong>Error!</strong> Please choose council file.
                    </div>');
            }
            $queryfile = "SELECT * FROM files WHERE file_name='".$_FILES['file_name']['name']."'";
            $resultfile=mysql_query($queryfile);
            $countfile=mysql_num_rows($resultfile);

            $queryfile1 = "SELECT * FROM files WHERE d_id='$d_id' AND l_id='$l_id'";
            $resultfile1=mysql_query($queryfile1);
            $countfile1=mysql_num_rows($resultfile1);
            if($countfile >=1){
                $d_id;
                $l_id;
                while ($rowfile=mysql_fetch_assoc($resultfile)){
                    $d_idfile=$rowfile['d_id'];
                    $l_idfile=$rowfile['l_id'];

                }
                $querydis="SELECT * FROM la WHERE d_id='$d_idfile' AND l_id='$l_idfile'";
                $resultdis=mysql_query($querydis);
                $d_name;
                $l_name;
                while ($rowdis=mysql_fetch_assoc($resultdis)){
                    $d_name=$rowdis['d_name'];
                    $l_name=$rowdis['l_name'];

                }

                echo('<div class="alert alert-danger  alert-error">
                        <a href="#" class="close" data-dismiss="alert">&times;</a>
                        <strong>Error!</strong>'.$_FILES['file_name']['name'].' file is uploaded before to '.$d_name.' and '.$l_name.' local authority .
                    </div>');
            }
         elseif ($countfile1>=1){

           $file_name;
             while ($rowfile1=mysql_fetch_assoc($resultfile1)){
                 $file_name1=$rowfile1['file_name'];

             }
             $querydis1="SELECT * FROM la WHERE d_id='$d_id' AND l_id='$l_id'";
             $resultdis1=mysql_query($querydis1);
             $d_name1;
             $l_name1;
             while ($rowdis1=mysql_fetch_assoc($resultdis1)){
                 $d_name1=$rowdis1['d_name'];
                 $l_name1=$rowdis1['l_name'];

             }
             echo('<div class="alert alert-danger  alert-error">
                        <a href="#" class="close" data-dismiss="alert">&times;</a>
                        <strong>Error!</strong> '.$d_id.'-'.$d_name1.'  and '.$l_id.' - '.$l_name1.' local authority also have a file.Its name is '.$file_name1.'
                    </div>');
         }
            else{
                $uploaddir = 'Files/';
                $fileObj->singleFileUpload($_FILES['file_name']['name'], $_FILES['file_name']['tmp_name'], $uploaddir);
                $addeObj->setFileName($fileObj->getFilename());
           $addeObj->setLId($l_id);
            $addeObj->setDId($d_id);
            $addeObj->setDate($date);


            if ($addeObj->addFile()) {
                echo('<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>  
<strong>Success!</strong>Council details are added..</div>');
            }
        } }catch (Exception $ex) {
            echo('<div class="alert alert-danger  alert-error">
                        <a href="#" class="close" data-dismiss="alert">&times;</a>
                        <strong>Error!</strong>' . $ex->getMessage() . '
                    </div>');
        }
    }

}
?>
