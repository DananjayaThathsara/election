<?php
error_reporting(1);
include_once '../Model/dbConfig.php';
include_once('../Model/deleteClass.php');

//Check posting data ------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    //relative path
    //Database Insert part Start

    if($_POST['controller']=='deleteContactUser'){

        if (trim($_POST['c_id']) == nulls) {
            echo('<div class="alert alert-danger  alert-error">
                        <a href="#" class="close" data-dismiss="alert">&times;</a>
                        <strong>Error!</strong> Please Enter Required Feilds.
                    </div>');
        } else {
            $delObj = new deleteClass();

            try {
                $c_id = $_POST['c_id'];

                $delObj->setCId($c_id);
                $delObj->setCStatus('deactive');


                if ( $delObj->deleteContactUserDetails()) {

                    echo('<div class="alert alert-success">
 <a href="#" class="close" data-dismiss="alert">&times;</a>
  <strong>Success!</strong> Contact detail is deleted..
</div>');
                }

            } catch (Exception $ex) {
                echo('<div class="alert alert-danger  alert-error">
                        <a href="#" class="close" data-dismiss="alert">&times;</a>
                        <strong>Error!</strong>' . $ex->getMessage() . '
                    </div>');

            }
        }
    }

}
?>
