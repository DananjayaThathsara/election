<?php

/**
 * Created by PhpStorm.
 * User: Nethweb
 * Date: 10/23/2017
 * Time: 12:03 PM
 */
class registerClass
{
    private $confirm_id;
    private $user_name;
    private $user_email;
    private $user_pword;
    private $date;

    /**
     * @return mixed
     */
    public function getConfirmId()
    {
        return $this->confirm_id;
    }

    /**
     * @param mixed $confirm_id
     */
    public function setConfirmId($confirm_id)
    {
        $this->confirm_id = $confirm_id;
    }

    /**
     * @return mixed
     */
    public function getUserName()
    {
        return $this->user_name;
    }

    /**
     * @param mixed $user_name
     */
    public function setUserName($user_name)
    {
        $this->user_name = $user_name;
    }

    /**
     * @return mixed
     */
    public function getUserEmail()
    {
        return $this->user_email;
    }

    /**
     * @param mixed $user_email
     */
    public function setUserEmail($user_email)
    {
        $this->user_email = $user_email;
    }

    /**
     * @return mixed
     */
    public function getUserPword()
    {
        return $this->user_pword;
    }

    /**
     * @param mixed $user_pword
     */
    public function setUserPword($user_pword)
    {
        $this->user_pword = $user_pword;
    }

    /**
     * @return mixed
     */
    public function getDate()
    {
        return $this->date;
    }

    /**
     * @param mixed $date
     */
    public function setDate($date)
    {
        $this->date = $date;
    }

    public function saveToTemp()
    {
        $query = "SELECT * FROM temp_register WHERE user_email='" . $this->getUserEmail() . "'";

        $result = mysql_query($query);
        $count = mysql_num_rows($result);
        if ($count >= 1) {
            echo('<div class="alert alert-danger  alert-error">
                        <a href="#" class="close" data-dismiss="alert">&times;</a>
                        <strong>Sorry!</strong> Your email already registered with us.Try again with another email.
                    </div>');
        } else {

            // Insert data into database
            $sql = "INSERT INTO temp_register(confirm_id, user_name, user_email, user_pword,date)VALUES('" . $this->getConfirmId() . "','" . $this->getUserName() . "', '" . $this->getUserEmail() . "', '" . $this->getUserPword() . "', '" . $this->getDate() . "')";

            $result = mysql_query($sql);

// if suceesfully inserted data into database, send confirmation link to email
            if ($result) {
// ---------------- SEND MAIL FORM ----------------
                $url = $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI'];
                $confirm_code = $this->getConfirmId();
// send e-mail to ...
                $to = $this->getUserEmail();
// Your subject
                $subject = "Your confirmation link here";

// From
                $header = "from:ContactBook <nethfm@nethfm.lk>";

// Your message
                $message = "Your Comfirmation link \r\n";
                $message .= "Click on this link to activate your account \r\n";
                $message .= "$url/verification/verification.php?passkey=$confirm_code";

// send email
                $sentmail = mail($to, $subject, $message, $header);

            } // if not found
            else {
                echo('<div class="alert alert-danger  alert-error">
                        <a href="#" class="close" data-dismiss="alert">&times;</a>
                        <strong>Error!</strong> Not found your email in our database.
                    </div>');
            }

// if your email succesfully sent
            if ($sentmail) {

                echo('<div class="alert alert-success">
 <a href="#" class="close" data-dismiss="alert">&times;</a>
  <strong>Success!</strong> Your Confirmation link Has Been Sent To Your Email Address..
</div>');
            } else {
                echo('<div class="alert alert-danger  alert-error">
                        <a href="#" class="close" data-dismiss="alert">&times;</a>
                        <strong>Error!</strong>Cannot send Confirmation link to your e-mail address.
                    </div>');

            }
        }
    }

}