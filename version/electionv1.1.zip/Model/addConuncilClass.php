<?php

/**
 * Created by PhpStorm.
 * User: Nethweb
 * Date: 10/27/2017
 * Time: 10:37 AM
 */
class addConuncilClass
{
    private $c_id;
    private $d_id;
    private $c_code;
    private $c_name;
    private $date;
    private $status;

    /**
     * @return mixed
     */
    public function getCId()
    {
        return $this->c_id;
    }

    /**
     * @param mixed $c_id
     */
    public function setCId($c_id)
    {
        $this->c_id = $c_id;
    }

    /**
     * @return mixed
     */
    public function getDId()
    {
        return $this->d_id;
    }

    /**
     * @param mixed $d_id
     */
    public function setDId($d_id)
    {
        $this->d_id = $d_id;
    }

    /**
     * @return mixed
     */
    public function getCCode()
    {
        return $this->c_code;
    }

    /**
     * @param mixed $c_code
     */
    public function setCCode($c_code)
    {
        $this->c_code = $c_code;
    }

    /**
     * @return mixed
     */
    public function getCName()
    {
        return $this->c_name;
    }

    /**
     * @param mixed $c_name
     */
    public function setCName($c_name)
    {
        $this->c_name = $c_name;
    }

    /**
     * @return mixed
     */
    public function getDate()
    {
        return $this->date;
    }

    /**
     * @param mixed $date
     */
    public function setDate($date)
    {
        $this->date = $date;
    }

    /**
     * @return mixed
     */
    public function getStatus()
    {
        return $this->status;
    }

    /**
     * @param mixed $status
     */
    public function setStatus($status)
    {
        $this->status = $status;
    }


    public function addCouncil()
    {
        $query = "INSERT INTO council (d_id,c_code,c_name,date,status) VALUES('" . $this->getDId() . "','" . $this->getCCode() . "',
        '" . $this->getCName()."','" . $this->getDate()."','" . $this->getStatus()."') ";
        $result=mysql_query($query);
        if($result){
            return true;
        }else{
            throw new Exception(mysql_error());
        }
    }

}

