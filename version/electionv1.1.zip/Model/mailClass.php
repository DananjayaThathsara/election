<?php

/**
 * Created by PhpStorm.
 * User: Nethweb
 * Date: 10/28/2017
 * Time: 1:01 PM
 */
class mailClass
{

}