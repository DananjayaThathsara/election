<?php

/**
 * Created by PhpStorm.
 * User: Nethweb
 * Date: 10/26/2017
 * Time: 3:17 PM
 */
class updateClass
{
    private $user_name;
    private $user_email;
    private $user_pword;
    private $date;
    private $id;
    private $c_id;
    private $c_name;
    private $c_phone;
    private $c_email;
    private $c_remarks;
    private $c_group;

    /**
     * @return mixed
     */
    public function getCGroup()
    {
        return $this->c_group;
    }

    /**
     * @param mixed $c_group
     */
    public function setCGroup($c_group)
    {
        $this->c_group = $c_group;
    }

    /**
     * @return mixed
     */
    public function getCId()
    {
        return $this->c_id;
    }

    /**
     * @param mixed $c_id
     */
    public function setCId($c_id)
    {
        $this->c_id = $c_id;
    }

    /**
     * @return mixed
     */
    public function getCName()
    {
        return $this->c_name;
    }

    /**
     * @param mixed $c_name
     */
    public function setCName($c_name)
    {
        $this->c_name = $c_name;
    }

    /**
     * @return mixed
     */
    public function getCPhone()
    {
        return $this->c_phone;
    }

    /**
     * @param mixed $c_phone
     */
    public function setCPhone($c_phone)
    {
        $this->c_phone = $c_phone;
    }

    /**
     * @return mixed
     */
    public function getCEmail()
    {
        return $this->c_email;
    }

    /**
     * @param mixed $c_email
     */
    public function setCEmail($c_email)
    {
        $this->c_email = $c_email;
    }

    /**
     * @return mixed
     */
    public function getCRemarks()
    {
        return $this->c_remarks;
    }

    /**
     * @param mixed $c_remarks
     */
    public function setCRemarks($c_remarks)
    {
        $this->c_remarks = $c_remarks;
    }




    /**
     * @return mixed
     */
    public function getUserName()
    {
        return $this->user_name;
    }

    /**
     * @param mixed $user_name
     */
    public function setUserName($user_name)
    {
        $this->user_name = $user_name;
    }

    /**
     * @return mixed
     */
    public function getUserEmail()
    {
        return $this->user_email;
    }

    /**
     * @param mixed $user_email
     */
    public function setUserEmail($user_email)
    {
        $this->user_email = $user_email;
    }

    /**
     * @return mixed
     */
    public function getUserPword()
    {
        return $this->user_pword;
    }

    /**
     * @param mixed $user_pword
     */
    public function setUserPword($user_pword)
    {
        $this->user_pword = $user_pword;
    }

    /**
     * @return mixed
     */
    public function getDate()
    {
        return $this->date;
    }

    /**
     * @param mixed $date
     */
    public function setDate($date)
    {
        $this->date = $date;
    }

    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param mixed $id
     */
    public function setId($id)
    {
        $this->id = $id;
    }

    public function updateUserProfile(){
        $query="UPDATE registered_user SET user_name='".$this->getUserName()."' , user_email='".$this->getUserEmail()."' , user_pword='".$this->getUserPword()."' , date='".$this->getDate()."' WHERE id='".$this->getId()."'";

        $result=mysql_query($query);
        if($result){
            return true;
        }
        else{
            throw new Exception(mysql_error());
        }
    }
    public function updateContactUserDetails(){
        $query="UPDATE contact_details SET c_name='".$this->getCName()."' , c_email='".$this->getCEmail()."' , c_phone='".$this->getCPhone()."' , c_group='".$this->getCGroup()."',c_remarks='".$this->getCRemarks() ."' WHERE c_id='".$this->getCId()."'";
        $result=mysql_query($query);
        if($result){
            return true;
        }
        else{
            throw new Exception(mysql_error());
        }
    }
}