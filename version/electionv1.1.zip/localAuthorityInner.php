<!DOCTYPE html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="">

    <title>Election</title>
    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link href="css/style.css" rel="stylesheet">

</head>
<html>
<body>
<div class="container">
    <div class="row">
        <img src="img/top.png" class="img-responsive" width="100%">
    </div>
    <div class="row">
        <div style="width: 100%;height: 80px;background: #ccc;vertical-align: middle;text-align: center">Ad Space</div>
    </div>
    <?php
    if(isset($_GET['d_id'])){
        $d_id=$_GET['d_id'];
    }  if(isset($_GET['l_id'])){
        $l_id=$_GET['l_id'];
    }
    ?>
    <div class="row">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                <li class="breadcrumb-item"><a href="distrctInner.php?d_id=<?php echo $d_id;?>&l_id=<?php echo $l_id;?>">Local Authority</a></li>
                <li class="breadcrumb-item active" aria-current="page">Result</li>
            </ol>
        </nav>
        <?php

        include_once 'Model/dbConfig.php';
        $query="SELECT * FROM la WHERE d_id='$d_id' AND  l_id='$l_id'";
        $result=mysql_query($query);

        while ($row=mysql_fetch_assoc($result)){

        ?>
        <h2><?php echo $row['d_name']?> - <?php echo $row['l_name']?></h2>
<?php }?>
        <div class="table-responsive">
        <table class="table table-striped">
            <thead>
            <tr>
                <th>Party</th>
                <th>Votes</th>
                <th>Precentage</th>
                <th>Selected Members</th>
                <th>Calculated Members</th>
                <th>Total Members</th>
            </tr>
            </thead>
            <tbody>
            <?php



$query23="SELECT lp.p_votes as p_votes,lpm.elected_mem,lpm.caculated_mem,sa.tot_valid_votes,pa.p_name_short,pa.p_image_name,pa.p_name
FROM la_party as lp 
LEFT JOIN la_party_members as lpm ON lp.p_id=lpm.p_id AND lp.d_id=lpm.d_id AND lp.l_id=lpm.l_id
LEFT JOIN sammary as sa ON lp.d_id = sa.d_id AND lp.l_id = sa.l_id
LEFT JOIN party as pa ON lp.p_id = pa.p_id

 WHERE lp.d_id='$d_id' AND lp.l_id='$l_id' ORDER BY lp.p_votes DESC
";

            $result23=mysql_query($query23);
            if($result23){

            while ($row23=mysql_fetch_assoc($result23)){


            ?>
            <tr>
                <td>
                    <div class="ele_symbol">
                        <img src="party_logo/<?php echo $row23['p_image_name']?>" width="30" height="30" class="img-responsive" alt="UNP">
                    </div>
                    <div class="ele_symbol_text" style="font-size: 14px"><?php echo $row23['p_name']?> - <?php echo $row23['p_name_short']?></div>
                </td>
                <td><?php echo number_format($row23['p_votes']);?></td>

                <td>

                <?php $precentage=($row23['p_votes']/$row23['tot_valid_votes'])*100;

                                echo round($precentage,2) ;?> %


                </td>
                <td><?php echo $row23['elected_mem']?></td>
                <td><?php echo $row23['caculated_mem']?></td>
                <td><?php echo $row23['caculated_mem']+$row23['elected_mem'];?></td>

            </tr>
            <?php }}else{
                echo 'Still result not release';
            }?>

            </tbody>
        </table></div>
        <div class="col-md-8">
            <div style="width: 100%;height:90px;background: #ccc;text-align: center;margin: 0px;padding: 0px">Ad space</div>
            <br>

            <table class="table table-bordered table-hover">
                <thead>
                <tr>
                    <th>Total Members</th>
                    <th>Valid Votes</th>
                    <th>Rejected Votes</th>
                    <th>Polled Votes</th>
                    <th>Registered Votes</th>
                 </tr>
                </thead>
                <tbody>
                <?php
                $querysu="SELECT * FROM sammary WHERE d_id='$d_id' AND l_id='$l_id'";
                $resultsu=mysql_query($querysu);

                while ($rowsu=mysql_fetch_assoc($resultsu)){
                ?>
                <tr>
                    <td><?php echo $rowsu['tot_mem'];?></td>
                    <td><?php echo number_format($rowsu['tot_valid_votes']);?></td>
                    <td><?php echo number_format($rowsu['rejected_votes']);?></td>
                    <td><?php echo number_format($rowsu['polled_votes']);?></td>
                    <td><?php echo number_format($rowsu['tot_reg_votes']);?></td>
                </tr>
<?php }?>
                </tbody>
            </table>
            <br>
            <div style="width: 100%;height:90px;background: #ccc;text-align: center;margin: 0px;padding: 0px">Ad space</div>
        </div>
        <div class="col-md-4">
            <div style="width: 100%;height:90px;background: #ccc;text-align: center;margin: 0px;padding: 0px">Ad space</div>
            <?php
            if(isset($_GET['d_id'])){
                $d_id=$_GET['d_id'];
            }  if(isset($_GET['l_id'])){
                $l_id=$_GET['l_id'];
            }

            $query="SELECT * FROM la WHERE d_id='$d_id' LIMIT 1";
            $result=mysql_query($query);

            while ($row=mysql_fetch_assoc($result)){

                ?>
                <h4><?php echo $row['d_name']?> - Local Authorities</h4>
            <?php }?>

                <table class="table table-striped">
                    <thead>
                    <tr>
                        <th>Local Authority Name</th>
                        <th style="text-align: center">Action</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                    if(isset($_GET['d_id'])){
                        $d_id=$_GET['d_id'];
                    }
                    include_once 'Model/dbConfig.php';
                    $query="SELECT * FROM la WHERE d_id='$d_id'";
                    $result=mysql_query($query);

                    while ($row=mysql_fetch_assoc($result)){

                        ?>
                        <tr>
                            <td>
                                <?php echo $row['l_name'];?>
                            </td>
                            <td style="text-align: center"><a href="localAuthorityInner.php?d_id=<?php echo $row['d_id']; ?>&l_id=<?php echo $row['l_id']; ?>">View</a></td>
                        </tr>
                    <?php }?>

                    </tbody>
                </table>

       </div>



<?php
include_once 'Model/dbConfig.php';
$query="SELECT * FROM file_name ORDER BY date DESC limit 2 ";
$result=mysql_query($query);
while ($row=mysql_fetch_assoc($result)){
    $url="electionadmin/Files/".$row['file_name'];
    $xml = simplexml_load_file("electionadmin/Files/".$row['file_name']) or die("Error: Cannot create object");

    foreach ($xml->summary as $vots) {
        $vv= $vots->valid_votes;
        $vv = intval(preg_replace('/[^\d.]/', '', $vv));

        $vj= $vots->rejected;
        $vj = intval(preg_replace('/[^\d.]/', '', $vj));

        $vvc=(int)$vv;
        $vjc=(int)$vj;

        $pollv=$vvc+$vjc;
        $vvp=($vvc/$pollv)*100;
        $pollv=number_format($pollv);


    }
}
?>

<!-- Bootstrap core JavaScript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

<script src="../js/bootstrap.min.js"></script>
<script>
    $(document).ready(function() {
        $('.progress .progress-bar').css("width",
            function() {
                return $(this).attr("aria-valuenow") + "%";
            }
        )
    });

</script>

</body>
</html>